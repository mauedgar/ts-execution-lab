param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-fA-F]{64}$')][string]$ExpectedRunnerSha256)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$gate='TS-AI-ACTIONS-LOCKFILE-001-R5B'
$stage='ENTRY'
$root=Join-Path $env:LOCALAPPDATA 'TS-AI-ACTIONS-LOCKFILE-001\run\ACTIONS-LOCKFILE-001-R5B'
$expectedBin='a64179817d7605d705e805475a09b5ef0be12a3469477d8607350f1f3cc26d8b'
$bin=Join-Path $env:LOCALAPPDATA 'TS-AI-ACTIONS-LOCKFILE-001\bin\gh-actions-lock-v0.4.0-windows-amd64.exe'
$record=@{gate=$gate;status='UNKNOWN';results=@();input_sha256=@{};terminal_stage='';runner_sha256='';dependencies=@{python='3.12.15';ruamel_yaml='0.18.17';cli='v0.4.0'};effects=@{Product='NONE_AUTHORIZED';ActionDispatch='NONE_AUTHORIZED';GitPush='NONE_AUTHORIZED'}}
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()}
function WriteReceipt([string]$status){
  $record.status=$status
  $record.terminal_stage=$script:stage
  if(Test-Path -LiteralPath $root){
    $receipt=Join-Path $root 'R5_RECEIPT.json'
    ($record | ConvertTo-Json -Depth 30) | Set-Content -LiteralPath $receipt -Encoding utf8 -ErrorAction Stop
    Write-Output ('RECEIPT_SHA256 '+(Hash $receipt))
  }
  Write-Output ('TERMINAL '+$status+' stage='+$script:stage+' cases='+@($record.results).Count)
}
function TestPreflight {
  $script:stage='INTEGRITY_AND_PARSER'
  if(Test-Path -LiteralPath $root){throw 'BLOCKED_RUN_ROOT_ALREADY_EXISTS'}
  $runner=(Hash $PSCommandPath)
  if($runner -ne $ExpectedRunnerSha256.ToLowerInvariant()){throw 'BLOCKED_SELF_RUNNER_SHA'}
  $record.runner_sha256=$runner
  $manifestPath=Join-Path $PSScriptRoot 'MANIFEST.json'
  $script:manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
  if($manifest.gate -ne $gate){throw 'BLOCKED_MANIFEST_IDENTITY'}
  foreach($key in @('policy.py','test_policy.py','fixture/.github/workflows/baseline.yml','fixture/.github/workflows/actions.lock','fixture/catalog.json')){
    $file=Join-Path $PSScriptRoot $key
    if(-not(Test-Path -LiteralPath $file)){throw ('BLOCKED_MISSING_FILE '+$key)}
    $actual=Hash $file
    if($actual -ne $manifest.file_hashes.$key){throw ('BLOCKED_FIXTURE_SHA '+$key)}
    $record.input_sha256.$key=$actual
  }
  if(-not(Test-Path -LiteralPath $bin) -or (Hash $bin) -ne $expectedBin){throw 'BLOCKED_OFFICIAL_BINARY_HASH'}
  $uv=Get-Command uv -ErrorAction SilentlyContinue
  $git=Get-Command git -ErrorAction SilentlyContinue
  if(-not $uv -or -not $git){throw 'BLOCKED_UV_OR_GIT'}
  $record.input_sha256['cli_binary']=$expectedBin
  $tokens=$null;$parseErrors=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($PSCommandPath,[ref]$tokens,[ref]$parseErrors)
  if(@($parseErrors).Count -gt 0){throw 'BLOCKED_RUNNER_PARSER'}
}
function ExecCase([string]$id,[string]$program,[string[]]$arglist,[int]$expectedExit,[string]$expectedText){
  $script:stage=$id
  $out=Join-Path $root ($id+'.stdout.txt');$err=Join-Path $root ($id+'.stderr.txt')
  # Scoped to this preauthorized attempt. Do not overwrite the original R1-R4 roots.
  & $program @arglist 1>$out 2>$err
  $exitCode=$LASTEXITCODE
  $stderr=if(Test-Path $err){Get-Content -LiteralPath $err -Raw -ErrorAction SilentlyContinue}else{''}
  $stdout=if(Test-Path $out){Get-Content -LiteralPath $out -Raw -ErrorAction SilentlyContinue}else{''}
  $combined=([string]$stdout+' '+[string]$stderr)
  $result=[pscustomobject]@{id=$id;exit_code=$exitCode;expected_exit=$expectedExit;stdout_sha256=(Hash $out);stderr_sha256=(Hash $err);expected_text=$expectedText;semantic_pass=($exitCode -eq $expectedExit -and $combined.Contains($expectedText))}
  $record.results+=@($result)
  ($result|ConvertTo-Json -Compress)|Add-Content -LiteralPath (Join-Path $root 'RESULTS.ndjson') -Encoding utf8
  Write-Output ('CASE '+$id+' exit='+$exitCode+' semantic='+$result.semantic_pass)
  if(-not $result.semantic_pass){throw ('FAILED_CASE '+$id)}
}
try{
  TestPreflight
  $stage='NEW_ISOLATED_ROOT'
  [void][System.IO.Directory]::CreateDirectory($root)
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'policy.py') -Destination (Join-Path $root 'policy.py') -ErrorAction Stop
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'test_policy.py') -Destination (Join-Path $root 'test_policy.py') -ErrorAction Stop
  [void][System.IO.Directory]::CreateDirectory((Join-Path $root '.github\workflows'))
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fixture/.github/workflows/baseline.yml') -Destination (Join-Path $root '.github\workflows\baseline.yml') -ErrorAction Stop
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fixture/.github/workflows/actions.lock') -Destination (Join-Path $root '.github\workflows\actions.lock') -ErrorAction Stop
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fixture/catalog.json') -Destination (Join-Path $root 'catalog.json') -ErrorAction Stop
  Push-Location $root
  try{
    $stage='GIT_LOCAL_ONLY'
    & git init -q | Out-Null
    if($LASTEXITCODE -ne 0){throw 'BLOCKED_LOCAL_GIT_INIT'}
    $uvArgs=@('run','--no-project','--python','3.12.15','--with','ruamel.yaml==0.18.17','python','-m','unittest','-q','test_policy.py')
    ExecCase 'T01_python_policy_37_tests' 'uv' $uvArgs 0 'Ran 38 tests'
    $stage='T02_POLICY_BASELINE'
    ExecCase 'T02_policy_baseline' 'uv' @('run','--no-project','--python','3.12.15','--with','ruamel.yaml==0.18.17','python','policy.py','--root','.','--catalog','catalog.json','--workflow','.github/workflows/baseline.yml') 0 '"status": "PASS"'
    $stage='T03_LOCKFILE_LOCAL'
    ExecCase 'T03_gh_verify_local' $bin @('--verify-local') 0 'complete lockfile coverage'
    $stage='T04_LOCKFILE_PROVENANCE'
    ExecCase 'T04_gh_verify_online' $bin @('--verify') 0 'workflow valid'
    $stage='RESTORE_ATTESTATION'
    foreach($key in @('policy.py','test_policy.py','fixture/.github/workflows/baseline.yml','fixture/.github/workflows/actions.lock')){
      $dst=switch($key){
        'fixture/.github/workflows/baseline.yml' {Join-Path $root '.github\workflows\baseline.yml'}
        'fixture/.github/workflows/actions.lock' {Join-Path $root '.github\workflows\actions.lock'}
        default {Join-Path $root $key}
      }
      if((Hash $dst) -ne $manifest.file_hashes.$key){throw ('FAILED_POSTSTATE_HASH '+$key)}
    }
    $record.poststate_sha256=@{baseline=(Hash (Join-Path $root '.github\workflows\baseline.yml'));lockfile=(Hash (Join-Path $root '.github\workflows\actions.lock'))}
    $stage='COMPLETE'
    WriteReceipt 'R5_COMPLETED_PENDING_IR003'
    exit 0
  }finally{Pop-Location}
}catch{
  $record.failure_reason=$_.Exception.Message
  Write-Output ('ERROR '+$record.failure_reason)
  if(Test-Path -LiteralPath $root){WriteReceipt 'R5_FAILED_OR_BLOCKED'}else{Write-Output ('TERMINAL BLOCKED_PRECONDITION stage='+$stage)}
  exit 11
}

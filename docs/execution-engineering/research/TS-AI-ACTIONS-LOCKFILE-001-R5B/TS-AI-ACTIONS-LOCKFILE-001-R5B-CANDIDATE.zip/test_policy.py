#!/usr/bin/env python3
"""Isolated R5 fixture matrix. No network, product repo, or git effects."""
import hashlib
import json
import tempfile
from pathlib import Path
import unittest

from policy import Policy

SHA = 'a' * 40
SHA_OTHER = 'b' * 40
DIGEST = 'c' * 64
REMOTE = f'actions/reusable-workflows/.github/workflows/basic-validation.yml@{SHA}'
REMOTE2 = f'actions/reusable-workflows/.github/workflows/child.yml@{SHA_OTHER}'


def wf(jobs):
    return 'name: synthetic\non: [push]\njobs:\n' + jobs


BASE = wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n')


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='r5-isolated-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.write('.github/workflows/test.yml', BASE)
        self.catalog = {}

    def write(self, rel, data):
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(data, encoding='utf-8')

    def add_snapshot(self, key, content, name):
        rel='snapshots/' + name
        self.write(rel,content)
        self.catalog[key] = {'path':rel,'sha256':hashlib.sha256((self.root/rel).read_bytes()).hexdigest()}

    def result(self):
        return Policy(self.root,self.catalog).verify(['.github/workflows/test.yml'])

    def assertBlocked(self, code):
        r=self.result()
        self.assertEqual(r['status'],'BLOCKED',r)
        self.assertIn(code,[x['code'] for x in r['findings']],r)

    def test_01_clean_baseline(self):
        r=self.result();self.assertEqual(r['status'],'PASS');self.assertIn('action_requires_gh_actions_lock_verify',[x['kind'] for x in r['graph_edges']])

    def test_02_mutable_reusable_main(self):
        self.write('.github/workflows/test.yml', wf(f'  ext:\n    uses: actions/reusable-workflows/.github/workflows/basic-validation.yml@main\n'))
        self.assertBlocked('REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED')

    def test_03_reusable_tag(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: actions/reusable-workflows/.github/workflows/basic-validation.yml@v1\n'))
        self.assertBlocked('REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED')

    def test_04_reusable_expression(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: ${{ github.repository }}/.github/workflows/test.yml@main\n'))
        self.assertBlocked('REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED')

    def test_05_sha_no_snapshot(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.assertBlocked('EXTERNAL_TRANSITIVE_SNAPSHOT_REQUIRED')

    def test_06_sha_snapshot_clean(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,BASE,'child.yml')
        self.assertEqual(self.result()['status'],'PASS')

    def test_07_sha_snapshot_tampered(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,BASE,'child.yml')
        self.write('snapshots/child.yml', BASE+'#tampered\n')
        self.assertBlocked('SNAPSHOT_HASH_MISMATCH')

    def test_08_nested_transitive_missing_snapshot(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,wf(f'  child:\n    uses: {REMOTE2}\n'),'child.yml')
        self.assertBlocked('EXTERNAL_TRANSITIVE_SNAPSHOT_REQUIRED')

    def test_09_nested_transitive_closed(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,wf(f'  child:\n    uses: {REMOTE2}\n'),'child.yml')
        self.add_snapshot(REMOTE2,BASE,'grandchild.yml')
        r=self.result();self.assertEqual(r['status'],'PASS',r);self.assertEqual(len(r['snapshots']),2)

    def test_10_container_tag(self):
        self.write('.github/workflows/test.yml', wf('  main:\n    runs-on: ubuntu-latest\n    container: node:22\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_11_container_digest_pass(self):
        self.write('.github/workflows/test.yml',wf(f'  main:\n    runs-on: ubuntu-latest\n    container: node:22@sha256:{DIGEST}\n    steps:\n      - run: echo ok\n'))
        self.assertEqual(self.result()['status'],'PASS')

    def test_12_container_mapping(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    container:\n      image: node:22\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_13_service_tag(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    services:\n      db:\n        image: postgres:15\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_14_service_digest_pass(self):
        self.write('.github/workflows/test.yml',wf(f'  main:\n    runs-on: ubuntu-latest\n    services:\n      db:\n        image: postgres@sha256:{DIGEST}\n    steps:\n      - run: echo ok\n'))
        self.assertEqual(self.result()['status'],'PASS')

    def test_15_docker_step_tag(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: docker://node:22\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_16_docker_step_digest(self):
        self.write('.github/workflows/test.yml',wf(f'  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: docker://node@sha256:{DIGEST}\n'))
        self.assertEqual(self.result()['status'],'PASS')

    def test_17_container_matrix_expression(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    strategy:\n      matrix:\n        image: [node:22]\n    container: ${{ matrix.image }}\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_18_container_expression(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    container: ${{ vars.IMAGE }}\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_19_local_reusable_nested(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: ./.github/workflows/child.yml\n'))
        self.write('.github/workflows/child.yml',wf('  main:\n    runs-on: ubuntu-latest\n    container: node:22\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_20_local_action_nested_docker(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: ./.github/actions/custom\n'))
        self.write('.github/actions/custom/action.yml','name: custom\nruns:\n  using: composite\n  steps:\n    - uses: docker://node:22\n')
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_21_local_action_node_unsupported(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: ./.github/actions/custom\n'))
        self.write('.github/actions/custom/action.yml','name: custom\nruns:\n  using: node24\n  main: main.js\n')
        self.assertBlocked('LOCAL_ACTION_UNSUPPORTED_FAIL_CLOSED')

    def test_22_yaml_duplicate_keys(self):
        self.write('.github/workflows/test.yml','jobs:\n  x:\n    runs-on: ubuntu-latest\n  x:\n    runs-on: ubuntu-latest\n')
        self.assertBlocked('YAML_INVALID_OR_DUPLICATE_KEY')

    def test_23_yaml_malformed(self):
        self.write('.github/workflows/test.yml','jobs:\n  x: [\n')
        self.assertBlocked('YAML_INVALID_OR_DUPLICATE_KEY')

    def test_24_symlink_traversal(self):
        outside=self.root.parent / (self.root.name+'_external.yml')
        outside.write_text(BASE)
        self.addCleanup(lambda:outside.unlink(missing_ok=True))
        (self.root/'.github/workflows/test.yml').unlink()
        (self.root/'.github/workflows/test.yml').symlink_to(outside)
        self.assertBlocked('FILE_NOT_TRUSTED_OR_MISSING')

    def test_25_invalid_local_parent(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: ./../.github/workflows/test.yml\n'))
        self.assertBlocked('LOCAL_REUSABLE_WORKFLOW_INVALID')

    def test_26_unused_catalog_entry(self):
        self.add_snapshot(REMOTE,BASE,'unused.yml')
        self.assertBlocked('CATALOG_UNUSED_OR_UNREACHABLE')

    def test_27_snap_catalog_bad_hash(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,BASE,'child.yml')
        self.catalog[REMOTE]['sha256']='0'*64
        self.assertBlocked('SNAPSHOT_HASH_MISMATCH')

    def test_28_bad_sha_length(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: owner/repo/.github/workflows/test.yml@1234\n'))
        self.assertBlocked('REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED')

    def test_29_invalid_digest_length(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    container: node@sha256:1234\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_30_no_workflows(self):
        r=Policy(self.root,self.catalog).verify([])
        self.assertEqual(r['status'],'BLOCKED')
        self.assertEqual(r['findings'][0]['code'],'NO_WORKFLOW_FILES')

    def test_31_local_cycle(self):
        self.write('.github/workflows/test.yml',wf('  ext:\n    uses: ./.github/workflows/child.yml\n'))
        self.write('.github/workflows/child.yml',wf('  ext:\n    uses: ./.github/workflows/test.yml\n'))
        self.assertBlocked('TRANSITIVE_CYCLE_DETECTED')

    def test_32_remote_snapshot_local_escape(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n'))
        self.catalog[REMOTE]={'path':'../out.yml','sha256':'0'*64}
        self.assertBlocked('SNAPSHOT_PATH_UNTRUSTED')

    def test_33_duplicate_external_dependency(self):
        self.write('.github/workflows/test.yml',wf(f'  ext:\n    uses: {REMOTE}\n  ext2:\n    uses: {REMOTE}\n'))
        self.add_snapshot(REMOTE,BASE,'child.yml')
        self.assertEqual(self.result()['status'],'PASS')

    def test_34_no_job_mapping(self):
        self.write('.github/workflows/test.yml','name: bad\non: push\njobs: []\n')
        self.assertBlocked('WORKFLOW_JOBS_INVALID')

    def test_35_container_null(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    container: null\n    steps:\n      - run: echo ok\n'))
        self.assertBlocked('IMAGE_IMMUTABLE_DIGEST_REQUIRED')

    def test_36_local_composite_pinned(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: ./.github/actions/custom\n'))
        self.write('.github/actions/custom/action.yml',f'name: custom\nruns:\n  using: composite\n  steps:\n    - uses: docker://node@sha256:{DIGEST}\n')
        self.assertEqual(self.result()['status'],'PASS')

    def test_37_missing_action_file(self):
        self.write('.github/workflows/test.yml',wf('  main:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: ./.github/actions/custom\n'))
        self.assertBlocked('FILE_NOT_TRUSTED_OR_MISSING')

    def test_38_snapshot_exact_crlf_bytes(self):
        self.write('.github/workflows/test.yml', wf(f'  ext:\n    uses: {REMOTE}\n'))
        raw=BASE.replace('\n','\r\n').encode('utf-8')
        rel='snapshots/crlf.yml'
        p=self.root/rel
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(raw)
        self.catalog[REMOTE]={'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        self.assertEqual(self.result()['status'],'PASS')


if __name__=='__main__':
    unittest.main(verbosity=2)

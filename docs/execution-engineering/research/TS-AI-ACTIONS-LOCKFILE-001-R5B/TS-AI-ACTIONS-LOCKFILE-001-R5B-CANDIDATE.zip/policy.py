#!/usr/bin/env python3
"""R5 experimental fail-closed GitHub Actions YAML supply chain policy.

Research-grade only. Source snapshots must come from trusted immutable sources;
this scanner verifies their exact bytes against an explicit catalog, but does not
itself authenticate network source provenance or replace gh-actions-lock --verify.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, asdict
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any

try:
    from ruamel.yaml import YAML
except ImportError as exc:
    raise SystemExit("BLOCKED_DEPENDENCY: ruamel.yaml required, no fallback permissive parser") from exc

SHA40 = r"[0-9a-fA-F]{40}"
SHA256 = r"[0-9a-fA-F]{64}"
EXTERNAL_WORKFLOW = re.compile(rf"^([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)/(.github/workflows/[A-Za-z0-9_./-]+\.(?:yml|yaml))@({SHA40})$")
EXTERNAL_ACTION = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_./-]+)?@[A-Za-z0-9_.-]+$")
DIGEST = re.compile(rf"^[A-Za-z0-9_./:-]+@sha256:({SHA256})$")
VALID_LOCAL_WORKFLOW = re.compile(r"^\./\.github/workflows/[A-Za-z0-9_./-]+\.(?:yml|yaml)$")
VALID_LOCAL_ACTION = re.compile(r"^\./\.github/actions/[A-Za-z0-9_./-]+$")
SAFE_PATH_PART = re.compile(r"^[A-Za-z0-9_.-]+$")
MAX_SIZE = 262144
MAX_FILES = 80
MAX_DEPTH = 15


@dataclass(frozen=True)
class Finding:
    code: str
    location: str
    details: str


class Policy:
    def __init__(self, root: Path, catalog: dict[str, dict[str, str]]):
        self.root = root.resolve(strict=True)
        self.catalog = catalog
        self.findings: list[Finding] = []
        self.seen: set[str] = set()
        self.edges: list[dict[str, str]] = []
        self.snapshots: list[dict[str, str]] = []
        self.loader = YAML(typ="safe", pure=True)
        self.loader.allow_duplicate_keys = False

    def fail(self, code: str, location: str, details: str = "") -> None:
        self.findings.append(Finding(code, location, details))

    def within(self, rel: str) -> Path | None:
        if rel.startswith("/") or "\\" in rel or "//" in rel or not rel:
            return None
        parts = rel.split("/")
        if any(part in (".", "..") or not SAFE_PATH_PART.fullmatch(part) for part in parts):
            return None
        path = self.root.joinpath(*parts)
        cursor = self.root
        for part in parts:
            cursor = cursor / part
            if cursor.is_symlink():
                return None
        try:
            actual = path.resolve(strict=True)
        except (OSError, RuntimeError):
            return None
        if not actual.is_relative_to(self.root) or actual.is_symlink() or path.is_symlink():
            return None
        return actual

    def load(self, location: str, rel: str) -> Any | None:
        path = self.within(rel)
        if path is None or not path.is_file() or path.stat().st_size > MAX_SIZE:
            self.fail("FILE_NOT_TRUSTED_OR_MISSING", location, rel)
            return None
        raw = path.read_bytes()
        try:
            text = raw.decode("utf-8-sig", "strict")
            docs = list(self.loader.load_all(text))
            if len(docs) != 1 or not isinstance(docs[0], dict):
                raise ValueError("expected one YAML mapping document")
            return docs[0]
        except Exception as exc:
            self.fail("YAML_INVALID_OR_DUPLICATE_KEY", location, type(exc).__name__)
            return None

    def catalog_path(self, ref: str) -> str | None:
        # Only snapshots exact-matched to catalog entries can be scanned.
        record = self.catalog.get(ref)
        if not isinstance(record, dict) or set(record) != {"path", "sha256"}:
            self.fail("EXTERNAL_TRANSITIVE_SNAPSHOT_REQUIRED", ref, "catalog entry absent or malformed")
            return None
        rel, expected = record["path"], record["sha256"]
        if not isinstance(rel, str) or not isinstance(expected, str) or not re.fullmatch(SHA256, expected):
            self.fail("SNAPSHOT_CATALOG_INVALID", ref)
            return None
        path = self.within(rel)
        if path is None or not path.is_file() or path.stat().st_size > MAX_SIZE:
            self.fail("SNAPSHOT_PATH_UNTRUSTED", ref, rel)
            return None
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest.lower() != expected.lower():
            self.fail("SNAPSHOT_HASH_MISMATCH", ref, f"expected {expected}, observed {digest}")
            return None
        self.snapshots.append({"ref": ref, "sha256": digest, "path": rel})
        return rel

    def image_check(self, value: Any, loc: str) -> None:
        if isinstance(value, dict):
            value = value.get("image")
        if not isinstance(value, str) or "${{" in value or "$" in value or not DIGEST.fullmatch(value):
            self.fail("IMAGE_IMMUTABLE_DIGEST_REQUIRED", loc, str(value)[:160])

    def action_check(self, use: Any, loc: str, depth: int) -> None:
        if not isinstance(use, str):
            self.fail("ACTION_REFERENCE_INVALID", loc)
            return
        if use.startswith("docker://"):
            self.image_check(use.removeprefix("docker://"), loc)
        elif use.startswith("./"):
            if not VALID_LOCAL_ACTION.fullmatch(use):
                self.fail("LOCAL_ACTION_PATH_INVALID", loc, use)
                return
            rel = use[2:].rstrip("/") + "/action.yml"
            self.scan(rel, depth + 1, kind="action")
        elif EXTERNAL_ACTION.fullmatch(use) and "${{" not in use:
            # A non-SHA external action is permitted only because gh-actions-lock
            # must independently validate and lock direct/transitive action refs.
            self.edges.append({"kind": "action_requires_gh_actions_lock_verify", "from": loc, "to": use})
        else:
            self.fail("ACTION_REFERENCE_INVALID", loc, use)

    def workflow_ref(self, use: Any, loc: str, depth: int) -> None:
        if not isinstance(use, str) or "${{" in use or "$" in use:
            self.fail("REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED", loc, str(use))
            return
        if use.startswith("./"):
            if not VALID_LOCAL_WORKFLOW.fullmatch(use):
                self.fail("LOCAL_REUSABLE_WORKFLOW_INVALID", loc, use)
                return
            self.edges.append({"kind": "local_workflow", "from": loc, "to": use})
            self.scan(use[2:], depth + 1, kind="workflow")
            return
        match = EXTERNAL_WORKFLOW.fullmatch(use)
        if match is None or ".." in match.group(3).split("/"):
            self.fail("REUSABLE_WORKFLOW_IMMUTABLE_SHA_REQUIRED", loc, use)
            return
        self.edges.append({"kind": "external_reusable", "from": loc, "to": use})
        rel = self.catalog_path(use)
        if rel:
            self.scan(rel, depth + 1, kind="workflow", label=use)

    def scan(self, rel: str, depth: int, kind: str = "workflow", label: str | None = None) -> None:
        node = label or rel
        if depth > MAX_DEPTH or len(self.seen) >= MAX_FILES:
            self.fail("GRAPH_BOUNDS_EXCEEDED", node)
            return
        if node in self.seen:
            # Repeated references safe; cycles in *active* graph need rejection.
            if node in getattr(self, "active", set()):
                self.fail("TRANSITIVE_CYCLE_DETECTED", node)
            return
        self.seen.add(node)
        if not hasattr(self, "active"):
            self.active = set()
        self.active.add(node)
        try:
            doc = self.load(node, rel)
            if doc is None:
                return
            if kind == "action":
                runs = doc.get("runs")
                if not isinstance(runs, dict) or runs.get("using") != "composite":
                    # Non-composite local actions may implement docker/node; no generic scan.
                    self.fail("LOCAL_ACTION_UNSUPPORTED_FAIL_CLOSED", node)
                    return
                steps = runs.get("steps")
                if not isinstance(steps, list):
                    self.fail("COMPOSITE_STEPS_INVALID", node)
                    return
                for i, step in enumerate(steps):
                    if not isinstance(step, dict):
                        self.fail("STEP_INVALID", f"{node}:runs.steps[{i}]")
                    elif "uses" in step:
                        self.action_check(step["uses"], f"{node}:runs.steps[{i}].uses", depth)
                return
            jobs = doc.get("jobs")
            if not isinstance(jobs, dict) or not jobs:
                self.fail("WORKFLOW_JOBS_INVALID", node)
                return
            for j, job in jobs.items():
                loc = f"{node}:jobs.{j}"
                if not isinstance(job, dict):
                    self.fail("JOB_INVALID", loc)
                    continue
                if "uses" in job:
                    self.workflow_ref(job["uses"], loc + ".uses", depth)
                    if "steps" in job or "container" in job:
                        self.fail("REUSABLE_JOB_UNEXPECTED_FIELDS", loc)
                if "container" in job:
                    self.image_check(job["container"], loc + ".container")
                if "services" in job:
                    svc = job["services"]
                    if not isinstance(svc, dict):
                        self.fail("SERVICES_INVALID", loc)
                    else:
                        for name, cfg in svc.items():
                            self.image_check(cfg, loc + f".services.{name}")
                if "steps" in job:
                    if not isinstance(job["steps"], list):
                        self.fail("JOB_STEPS_INVALID", loc)
                    else:
                        for i, step in enumerate(job["steps"]):
                            if not isinstance(step, dict):
                                self.fail("STEP_INVALID", f"{loc}.steps[{i}]")
                            elif "uses" in step:
                                self.action_check(step["uses"], f"{loc}.steps[{i}].uses", depth)
        finally:
            self.active.discard(node)

    def verify(self, files: list[str]) -> dict[str, Any]:
        if not files:
            self.fail("NO_WORKFLOW_FILES", "root")
        for file in files:
            self.scan(file, 0)
        used = {s["ref"] for s in self.snapshots}
        for key in self.catalog:
            if key not in used:
                self.fail("CATALOG_UNUSED_OR_UNREACHABLE", key)
        return {"schema": "TS-AI-R5-POLICY-v1", "status": "PASS" if not self.findings else "BLOCKED", "findings": [asdict(x) for x in self.findings], "graph_edges": self.edges, "snapshots": self.snapshots, "workflow_count": len(self.seen), "asserted": "static_policy_only_requires_external_gh_actions_lock_verify"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--catalog", required=True)
    ap.add_argument("--workflow", action="append", required=True)
    args = ap.parse_args()
    root = Path(args.root)
    try:
        manifest = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
        if not isinstance(manifest, dict) or any(not isinstance(k,str) for k in manifest):
            raise ValueError("catalog must be mapping")
        result = Policy(root, manifest).verify(args.workflow)
    except Exception as exc:
        result = {"schema": "TS-AI-R5-POLICY-v1", "status": "BLOCKED", "findings": [{"code": "TOP_LEVEL_FAIL_CLOSED", "location": "runner", "details": type(exc).__name__}]}
    print(json.dumps(result,sort_keys=True,ensure_ascii=True))
    return 0 if result["status"] == "PASS" else 2

if __name__ == "__main__":
    sys.exit(main())

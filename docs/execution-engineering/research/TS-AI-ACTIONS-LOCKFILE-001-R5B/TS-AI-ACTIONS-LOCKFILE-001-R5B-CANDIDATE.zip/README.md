TS-AI-ACTIONS-LOCKFILE-001-R5B, experimental research-only candidate.
Use on notebook with an explicitly authorized, fresh, mechanical invocation.
Policy is fail-closed on unpinned job reusables, job containers/services and docker://; local composite action scans; nested local and catalog-pinned remote workflow graph.
SHA-256 of external snapshots proves file integrity only, NOT GitHub commit/path provenance. The provenance must be checked independently and gh-actions-lock --verify must separately PASS. Any missing transitive snapshot fails closed.
Known scope limits: no evaluation of arbitrary shell `run:` commands that invoke Docker, no scanning external third-party action source code, no trust proof from a caller-supplied snapshot catalog, no Product adoption. Under those constraints this tool is a RESEARCH COMPENSATING POLICY CANDIDATE, not an enforced security gate.
No automatic retry if unknown. R1–R4 roots preserved. UV may download Python 3.12.15 / ruamel.yaml 0.18.17 into user cache on first isolated invocation.

R5 original stopped on CRLF snapshot-hash test portability. R5B hashes actual written bytes and includes CRLF fixture regression test. R5 effects not repeated.
